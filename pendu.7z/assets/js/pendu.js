//window.onload = init();
let words7letter = ["EPAULES", "DENTELE", "CEREALE", "LETALES", "EPISODE", "CERISES", "LIBERTE", "ETOILES", "GLAUQUE", "HAMECON", "VANILLE", "VAUTOUR", "BRULURE", "CRAPULE", "CERTAIN", "TORNADE", "TRAITRE", "SCANNER", "TIEDEUR", "SAUVAGE", "TAMBOUR", "RAVIOLI", "CERVIDE", "RACINES", "PYTHONS"]
nbRandom = getRandomInt(0, words7letter.length - 1);
let wordMystery = words7letter[nbRandom];
console.log(wordMystery);
let myAlphabet = ("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
let tabMystery = []; //tableau du mot mystère
let tabResult = ["-", "-", "-", "-", "-", "-", "-"]; //tableau résultat pour placer lettres trouvées
tabMystery = wordMystery.split(''); //On transforme le mot mystère en tableau
let nbEssai = 8; //On initialise le nombre d'essais(max 10)
let failed = 0;
let found = false;
let test = document.querySelectorAll('.btn');
/*<button  class="N btn">N</button>*/
let myVar = myAlphabet.split('');
for (let i = 0; i < myVar.length; i++) {
    document.getElementById('alphabet').innerHTML += "<button class=" + myVar[i] + " btn onclick=" + "compare('"+myVar[i]+"')>" + myVar[i] + "</button>\n";
};
//document.getElementById('replay').addEventListener('click', function(){window.location.reload()})
document.addEventListener('keydown', (event) =>{
    let keyPressed = event.key;
    keyPressed = keyPressed.toUpperCase();
        if (myAlphabet.indexOf(keyPressed) !== -1){
            //removeFocus();
            compare(keyPressed);
        };
        return;   
})
/*function removeFocus(){
    document.activeElement.blur();
}*/
/*function init() {
    // Clear forms here
    document.getElementById("progress").value = "";
}*/

function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
}
function compare(letter) {
    
    let choice = document.getElementsByClassName(letter);
    choice[0].disabled = true;
    choice[0].classList.add(letter, "disabled");
    console.log(nbEssai);
    for (let i = 0; i <= tabMystery.length -
        1; i++) { //On entre dans la boucle qui va tester si la lettre se trouve dans le mot mystère
        if ((letter === tabMystery[i]) && (nbEssai > 0)) //Teste saisie ok et encore des essais
        {
            found = true;
            tabResult[i] = tabMystery[i]; //On remplit notre tableau pour afficher la progression
            document.getElementById("progress").value = tabResult.join(''); //On affiche la progression
            if (tabMystery.join('') == tabResult.join('')) //On vérifie que tout le mot n'a pas été trouvé
            {
                winfunc();
                document.getElementById('replay').classList.add("display");
                document.getElementById("resultat").innerHTML = " Bravo. Le mot était bien : " + tabResult.join(
                    '');
                    document.getElementById('message').className="green";
                document.getElementById('linkModal').click();
                
                //On félicite et on affiche le mot mystère et on sort de la fonction
            }
        } else {
            if (nbEssai <= 1 && (i=tabMystery.length-1)) { //nb d'essai dépassé
                loosefunc();
                document.getElementById('replay').classList.add("display");
                document.getElementById("resultat").innerHTML = " Désolé. Vous avez perdu. Le mot était :" +
                    tabMystery.join('');
                document.getElementById('message').className="red";
                document.getElementById('message').innerText = "DESOLE VOUS AVEZ PERDU";
                document.getElementById('linkModal').click();
                //Perdu. On affiche la solution et on sort de la fonction
            }
        }
    }
    if (found == false) {
        document.getElementById('image').style.display = "block";
        failed = failed + 1;
        document.getElementById('image').innerHTML = `<img src ="./assets/img/pendu${failed}.png">`;
        nbEssai -= 1; //On a cliquer sur "TESTER" donc on a grillé 1 essai
        document.getElementById("trialCount").innerHTML = nbEssai; 
    } else {
        found = false;
    }
}
let win = new Audio('./assets/media/applause.mp3');
function winfunc() {
    setTimeout(pause,3000);
    win.volume = 0.3;
    win.play();
}
let loose = new Audio('./assets/media/cloche.mp3');
function loosefunc() {
    setTimeout(pause,3000);
    loose.volume = 0.3;
    loose.play();

}
function pause(){
    loose.pause();
    win.pause();
}
